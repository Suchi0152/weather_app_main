import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';


void main() {
  runApp(const WeatherApp());
}


class WeatherApp extends StatelessWidget {
  const WeatherApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Weather App',


      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),


      home: const SplashScreen(),
    );
  }
}



